package hr.fer.ooup.lab4.model;

public interface GraphicalObjectListener {
    void graphicalObjectChanged(GraphicalObject go);
    void graphicalObjectSelectionChanged(GraphicalObject go);
}
