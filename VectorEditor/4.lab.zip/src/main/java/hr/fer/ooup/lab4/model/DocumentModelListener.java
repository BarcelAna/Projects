package hr.fer.ooup.lab4.model;

public interface DocumentModelListener {
    void documentChange();
}
