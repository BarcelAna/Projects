package hr.fer.oprpp1.fractals.complexParsing;

public class ComplexParserException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ComplexParserException(String msg) {
		super(msg);
	}

	public ComplexParserException() {
		// TODO Auto-generated constructor stub
	}
}
