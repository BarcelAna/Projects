package hr.fer.oprpp1.fractals.complexParsing;

public class ComplexLexerException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public ComplexLexerException() {
		
	}

	public ComplexLexerException(String msg) {
		super(msg);
	}
}
