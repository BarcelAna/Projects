package hr.fer.oprpp1.fractals;

public class CommandFormatException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public CommandFormatException(String msg) {
		super(msg);
	}
}
