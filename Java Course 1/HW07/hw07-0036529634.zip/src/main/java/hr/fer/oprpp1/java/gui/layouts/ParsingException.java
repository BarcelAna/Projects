package hr.fer.oprpp1.java.gui.layouts;

public class ParsingException extends RuntimeException {

	public ParsingException(String msg) {
		super(msg);
	}

	public ParsingException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
