package hr.fer.oprpp1.custom.scripting.lexer;

public class P_LexerException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public P_LexerException(String msg) {
		super(msg);
	}
}
