package hr.fer.oprpp1.hw02.prob1;

/**
 * Enum LexerState defines two working modes of lexer: BASIC and EXTENDED
 * @author anace
 *
 */
public enum LexerState {
	BASIC,
	EXTENDED
}
