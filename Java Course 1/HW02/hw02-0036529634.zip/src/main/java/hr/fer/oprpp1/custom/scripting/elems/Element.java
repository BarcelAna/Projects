package hr.fer.oprpp1.custom.scripting.elems;
/**
 * Class Element represents some expression like function, operator, variable, string or constant.
 * @author anace
 *
 */
public class Element {

	/**
	 * Returns element as string.
	 * @return string representation of element
	 */
	public String asText() {
		return "";
	}
}
