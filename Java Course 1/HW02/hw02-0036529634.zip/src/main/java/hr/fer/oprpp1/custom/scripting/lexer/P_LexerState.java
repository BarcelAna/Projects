package hr.fer.oprpp1.custom.scripting.lexer;

/**
 * Enum LexerState represents two working modes of lexer: TEXT and TAG
 * @author anace
 *
 */
public enum P_LexerState {
	TEXT,
	TAG
}
