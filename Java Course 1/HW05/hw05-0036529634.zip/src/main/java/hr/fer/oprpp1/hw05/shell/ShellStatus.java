package hr.fer.oprpp1.hw05.shell;
/**
 * Enum ShellStatus represents possible work statuses of shell: continue or terminate
 * @author anace
 *
 */
public enum ShellStatus {
	CONTINUE,
	TERMINATE
}
