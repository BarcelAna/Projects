package hr.fer.oprpp1.hw04.db;

public enum QueryTokenType {
	FIELD,
	OPERATOR,
	LITERAL,
	AND,
	EOF
}
