package hr.fer.oprpp2.beans;

public class Angles {
    private double sin;
    private double cos;

    public Angles(double sin, double cos) {
        this.sin = sin;
        this.cos = cos;
    }

    public double getSin() {
        return sin;
    }

    public double getCos() {
        return cos;
    }
}
